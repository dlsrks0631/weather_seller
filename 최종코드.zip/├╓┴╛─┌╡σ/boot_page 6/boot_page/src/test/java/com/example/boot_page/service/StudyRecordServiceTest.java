package com.example.boot_page.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudyRecordServiceTest {

    @Test
    void doSelectAll() {
    }

    @Test
    void doSelectOne() {
    }

    @Test
    void doInsert()
    }

    @Test
    void doUpdate() {
    }

    @Test
    void doDelete() {
    }
}