package com.example.boot_page;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootPageApplicationTests {

	@Test
	void contextLoads() {
	}



}
